<!-- jQuery library -->
<?php
include_once 'security.php';
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <title>Edit user Details</title> -->
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://phpcoder.tech/multiselect/js/jquery.multiselect.js"></script>
    <link rel="stylesheet" href="https://phpcoder.tech/multiselect/css/jquery.multiselect.css">
    
    
    <title>NUS Consulting Group | Add user</title>
    <link rel="icon" href="img/social-square-n-blue.png">
    <link rel="stylesheet" href="css/inviteusers.css">
    
</head>
<style type="text/css">
hr {
    margin-top: 0px;
    margin-bottom: 0px;
    border: 0;
    border-top: 1px solid #eee;
}
#role,#roleparentdata,.roleparent,.passwordvalue{
    width: 90%;
    margin: 10px 0 20px 20px;
    padding: 10px;
    border: 1.5px solid blue;
    background: white;
    border-radius: 5px;
}
.ms-options-wrap{
    width: 90%;
    margin: 10px 0 0px 20px;
    padding: 5px;
    border: 1.5px solid blue;
    background: white;
    border-radius: 5px;
}
.ms-options-wrap > button:focus, .ms-options-wrap > button {
    border:none;
}
.errlog {
    color:red;
    padding: 0px 0px 0px 19px;
}
.parentContainer {
    background: #fff;
    width: 400px;
    position: absolute;
    border: 2px solid #d2ddec;
    border-radius: 8px;
    top: auto;
    left: 50%;
    transform: translate(-50%);
    box-shadow: 0px 5px 12px 2px lightgrey;
}
</style>
<body>
    
    <section class="sec1Container">
        <div class="sec1Wrapper">
            <div class="parentContainer">
                <br>
                <h2>Add user</h2>
                <div class="close-btn" onclick='window.history.go(-1);'>&times;</div>
                <br>
                <hr color="#d2ddec">
                <form onsubmit="return checkpasswordlength()" action="postinviteuser.php" method="POST" class="parentAddForm">

                    <label class="userdata">User name</label>
                    <input autocomplete="off" type="text" name="username" class="userNames" placeholder="Enter username"  required>

                    <label class="emaildata">Enter Email</label>
                    <input autocomplete="off" type="text" name="emailId" class="emailiddata"  placeholder="Enter email"  required>
                    
                    <label class="role">Role</label>
            
                    <select onchange="ChangeDropdowns(this.value)" id="role" class="selecting" name="role">
                        <option value="*" >Select an option</option>
                        <option value="Admin"  >Admin</option>
                        <option value="NUS Manager"  >NUS Manager</option>
                        <option value="NUS User"  >NUS User</option>
                        <option value="Parent company">Parent company</option>
                        <option value="Client company">Client company</option>
                    </select>
                    <div class = "userform"  id='showunit' style="display:none" >
                    <label class="roleid">Parent company</label>
                   
                        <select id="showunit" name="parentcompany" id="showunit"  class="roleparent">
                            <option disabled selected>Select a parent company</option>
                             

<?php
include "dbconn.php";
                    $getparent =array();
                    $getparentdetails = "SELECT * FROM parentcompanydata";
                    $results = $conn->query($getparentdetails);
                        if ($results->num_rows > 0) {
                            while($row = $results->fetch_assoc()) {
                                $getparent[] = $row;
                            }
                        }
                       
                        foreach ($getparent as $key => $valueparent) {
                          
                          ?>
                            <option value="<?=$valueparent['parentcompany']?>"><?=$valueparent['parentcompany']?></option>
                            
                        <?php
                        }
                        ?>
                        </select>
                    </div>
                    
                  

                    <div class = "userform"  id='show' style="display:none" >
    
                    <label class="roleid">Client company</label>
                    <br>
                        <select  id="roleparentdata" name="bussinessunit[]" class="roleparent " multiple>
                            <!-- <option disabled selected>Select a client company</option> -->
                                <?php
                                    include "dbconn.php";  // Using database connection file here
                                
                                    $parentcompany = mysqli_query($conn, "SELECT * From clientcompanydata");  // Use select query here 

                                    while($parentcompanydata = mysqli_fetch_array($parentcompany))

                                    {
                                        echo "<option value='". $parentcompanydata['id'] ."'>" .$parentcompanydata['clientcompany'].'-'.$parentcompanydata['country'] ."</option>";  // displaying data in option menu
                                    }	
                                ?>  
                        </select>
                

                   
                    </div>

                    <label for="" class="password">Password</label>
     

                    <input type="password" class="passwordvalue" onkeyup="passwordlengthcheck(this.value)" name="password" placeholder="Enter your password" required><br>
                    <span class="errlog passwordval"></span>
                    
                    <hr color="#d2ddec">
                 
                    <div class="one" style="margin: 15px 0px 5px 22px;">
                        <button name="cancel" value="Cancel" type="reset" class="cancelClass cancelUser" onclick='window.history.go(-1);'>Cancel <img src="img/cancel-svgrepo-com.svg" alt="cancel icon" width="14px"></button>
                        <!-- <button type="submit" class="createClass" style="margin: 0px 0px 0px 83px;">Create Parent <img src="img/plus-white.svg" alt="plus icon" width="14px"></button> -->
                        <input value="Invite User" class="createClass inviteUser" id="enable_button" type="submit" name="submit" style="margin: 0px 0px 0px 121px;">
                    </div>
                    <br>
                </form>
            </div>
        </div>
    </section>



  <script>
    function passwordlengthcheck(val){
        var length = val.length;
        console.log(length);
        if(length < 8){
            $('.errlog').html('Password should be above 8 charactors');
        }else{
            $('.errlog').html('');
        }
    }
    function checkpasswordlength(){
        var charlength = $('.passwordvalue').val();
        var getlength = charlength.length;
        if(getlength < 8){
           return false;
        }
        return true;
    }
    function ChangeDropdowns() {
        const dropDown = document.getElementById('role').value;
        const div = document.getElementById('show');
        const div1 = document.getElementById('showunit');

        console.log('Inside Changedropdown client');
        
        console.log(dropDown)
        if(dropDown == "Client company") {
            div.style.display = 'block';
            div1.style.display = 'block';
        }
        else if(dropDown == "Parent company") {
            div.style.display = 'none';
            div1.style.display = 'block';
        }
        else {
            div.style.display = 'none';
            div1.style.display = 'none';
        }
    }
    </script>

<script>
    jQuery('#roleparentdata').multiselect({
    columns: 1,
    placeholder: 'Select one or more Bussiness units',
});
</script>

<script>
        function togglepopUp() {
            document.getElementById("popup-1").classList.toggle("active");
        }
        
</script>
   
<script>
    function getclientdetails(clientId){
        $.ajax({
        type:'POST',
        url: 'js/callbacks/getclientdeails.php',
        data:{
            'clientId':clientId
        
        },
        success: function(data){
            var obj = JSON.parse(data);
            $('.country').val(obj.clientcountry);
            $('.clientname').val(obj.clientname);
            console.log(data);
        }
        });
    }

function getparentdetails(parentId){
    $.ajax({
        type:'POST',
        url: 'js/callbacks/getparentdetails.php',
        data:{
            'parentId':parentId
        
        },
        success: function(data){
            $('.clint').html(data);
        }
        });
}
   </script>
</body>
 </html>
        
 









