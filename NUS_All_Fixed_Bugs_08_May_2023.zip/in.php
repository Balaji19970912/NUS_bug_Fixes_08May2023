
<?php
include 'dbconn.php';

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/chosen/1.1.0/chosen.jquery.min.js"></script>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous"> -->
    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://phpcoder.tech/multiselect/js/jquery.multiselect.js"></script>
    <link rel="stylesheet" href="https://phpcoder.tech/multiselect/css/jquery.multiselect.css">
    <!-- <link rel="stylesheet" href="css/inviteuser.css"> -->
        <title>NUS Consulting Group |Add user</title>
    <link rel="icon" href="img/social-square-n-blue.png">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap');
        body{
            background-color: whitesmoke;
            /* padding: 150px 0 0 0; */
            font-family: 'Roboto', sans-serif;
            font-style: normal;
            font-weight: 400;
            font-size: 15px;
        }


        select {
            padding: 10px 10px;
            width: 360px;
            background-color: rgb(255, 255, 255);
            cursor: pointer;
            color: #345DA6;
            border: 1px solid #1363F1;
            border-radius: 6px;
            margin: 0 50px;

        }

        lable {
            font-size: 15px;
            font-weight: 400;
        
            color: #345DA6;
            /* margin: 0 0 5px 10px; */
            margin: 0 50px;
            font-family: 'Roboto', sans-serif;
            font-style: normal;
            line-height: 152.4%;
            /* margin-bottom: 6px; */
            align-items: center;
            letter-spacing: -0.01em;
            padding: 0px !important;
        }
        input {
            padding: 10px 10px;
            width: 360px;
            background: #FFFFFF;
            background-color: white;
            border: 1px solid #D2DDEC;

            cursor: pointer;
            color: #345DA6;
            border: 1px solid #1363F1;
            border-radius: 6px;
            margin: 0 50px;
        }

        .head{
            font-family: 'Roboto', sans-serif;
            font-style: normal;
            font-weight: 400;
            font-size: 15px;
        }

        hr {
            margin-left: -25px;
            margin-top: 20px;
            margin-bottom: 20px;
            border: 0;
            border-top-color: currentcolor;
            border-top-style: none;
            border-top-width: 0px;
            border-top: 1px solid #eee;
        }

        .Adduser {
            font-size: 18px;
        font-weight: 700;
        }

        .close-btn {
            position: absolute;
            float: right;
            right: 35%;
            top: 2.5%;
            width: 30px;
            height: 30px;
            /* background: #222; */
            color: #000000;
            font-size: 25px;
            cursor: pointer;
        }
        .userdata, .emaildata, .role, .clientData, .password{
            margin: 0 50px;
            color: #345DA6;
            /* color: wheat; */
        }
        .userform {
            max-width: 500px;
            max-height: 900px;
            margin: auto;
            border-radius: 10px;
            padding: 20px 25px 0 25px;
            background: white;
        }
        .cancelUser {
            background: white;
            border: 1px solid #345da6;
            padding: 10px 20px;
            cursor: pointer;
            margin: 0 7px 0 10px;
            width: 120px;
            position: relative;
            left: 42%;
        }

        .inviteUser {
            background: #345da6;
            border: 1px solid #345da6;
            padding: 10px 20px;
            cursor: pointer;
            margin: 0 7px 0 10px;
            position: relative;
            left: 40%;
            color: whitesmoke;
            width: 120px;
        }
    </style>
</head>
<body>
          
<div class = "userform">
    <form  onsubmit="return checkpasswordlength()" action="postinviteuser.php" method="POST">
        <header class="head">
            <span class="Adduser ">Add user</span>
            <div class="close-btn" onclick='window.history.go(-1);'>&times;</div>
            <br>
            <hr class="lines">
            <label class="userdata">User name</label>
            <br>
            <br>
            <input autocomplete="off" type="text" name="username" class="userNames" placeholder="Enter username"  required>
            <br>
            <br>
            <label class="emaildata">Enter Email</label>
            <br>
            <br>
            <input autocomplete="off" type="text" name="emailId" class="emailiddata"  placeholder="Enter email"  required>
            <br>
            <br>
            <label class="role">Role</label>
            <br>
            <br>
            <select onchange="ChangeDropdowns(this.value)" id="role" class="selecting" name="role">
                <option value="*" >Select an option</option>
                <option value="Admin"  >Admin</option>
                <option value="NUS Manager"  >NUS Manager</option>
                <option value="NUS User"  >NUS User</option>
                <option value="Parent company">Parent company</option>
                <option value="Client company">Client company</option>
            </select>
            <br>
            <br>
            <div class="contents">
                <div class="clientDetails">
                    <label class="clientData">Parent Company</label>
                    <br>
                    <br>
                    <select  id="parent" name="parentid" onchange="parentdetails(this.value)">
                        <option selected disabled>Select Parent</option> 
                            <?php
                                $getparent =array();
                                $getparentdetails = "SELECT * FROM parentcompanydata";
                                $results = $conn->query($getparentdetails);
                                    if ($results->num_rows > 0) {
                                        while($row = $results->fetch_assoc()) {
                                            $getparent[] = $row;
                                        }
                                    }
                                
                                    foreach ($getparent as $key => $valueparent) {
                                    
                                    ?>
                                    <option value="<?=$valueparent['parentcompany']?>"><?=$valueparent['parentcompany']?></option>
                                        
                                    <?php
                                }
                            ?>
                    </select>
                </div>
            </div>
             
                <br>
                <div class="clientDetails">
                    <label class="clientData">Client Company</label>
                    <br>
                    <br>
                    <select  id="client" class="clientcom" name="clientcompany" multiple>
                        <option selected disabled>Select Client</option>
                    </select>
                </div>
                <br>
            
                <label for="" class="password">Password</label>
                <br>
                <br>
                <input type="password" class="passwordvalue" onkeyup="passwordlengthcheck(this.value)" name="password" placeholder="Enter your password" required><br>
                <span class="errlog passwordval"></span>
                <hr class="lines">
                <div class="clientbuttonSection">
                    <input name="cancel" value="Cancel" type="reset" class="cancelUser" onclick='window.history.go(-1);'>
                    <!-- <input value="Create Client" class="createClient" id="enable_button" type="submit" disabled> -->
                    <input value="Invite User" class="inviteUser" id="enable_button" type="submit" name="submit" >
                </div>  
            </form>
         </div>
    </div>
</body>


   
    
<script type="text/javascript">
  function parentdetails(parentId){
  $.ajax({
      type:'POST',
      url: 'js/callbacks/parentdetails.php',
      data:{
        'parentId':parentId
      
      },
      success: function(data){
        $('.clientcom').html(data);
      }
    });
}
  
</script>

<script>
$('#clients').multiselect({
    columns: 1,

    search: true
});
</script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>

</html>