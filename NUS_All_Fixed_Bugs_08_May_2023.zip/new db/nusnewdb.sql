-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 02, 2022 at 06:38 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nusnewdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `clientcompanydata`
--

CREATE TABLE `clientcompanydata` (
  `id` int(11) NOT NULL,
  `parentcompany` varchar(255) NOT NULL,
  `clientcompany` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `clientcompanydata`
--

INSERT INTO `clientcompanydata` (`id`, `parentcompany`, `clientcompany`, `country`) VALUES
(3, 'Qualesce', 'NUS Consulting Group', 'India'),
(4, 'Qualesce', 'Ji Solutions', 'Canada'),
(5, 'Ji Inc', 'Ji Trips', 'United Arab'),
(6, 'Shell Global', 'Shell UK', 'United Kingdom'),
(7, 'Shell Global', 'ABC', 'India');

-- --------------------------------------------------------

--
-- Table structure for table `enter_trade`
--

CREATE TABLE `enter_trade` (
  `tradeId` int(11) NOT NULL,
  `parentId` varchar(50) NOT NULL,
  `clientId` int(11) NOT NULL,
  `supplycontractid` varchar(20) NOT NULL,
  `mwh` varchar(30) NOT NULL,
  `percentage` varchar(30) NOT NULL,
  `tradevolume` varchar(50) NOT NULL,
  `baseload` varchar(50) NOT NULL,
  `effectiveprice` varchar(50) NOT NULL,
  `trade` varchar(30) NOT NULL,
  `tradevalue` varchar(20) NOT NULL,
  `tradingId` int(11) NOT NULL,
  `nustradeId` int(11) NOT NULL,
  `tradeDate` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `nususerdata`
--

CREATE TABLE `nususerdata` (
  `id` int(11) NOT NULL,
  `role` varchar(20) NOT NULL,
  `username` varchar(100) NOT NULL,
  `emailId` varchar(100) NOT NULL,
  `accountstatus` varchar(10) NOT NULL,
  `password` varchar(100) NOT NULL,
  `parentcompany` varchar(100) NOT NULL,
  `bussinessunit` varchar(255) NOT NULL,
  `active` enum('Active','Inactive') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nususerdata`
--

INSERT INTO `nususerdata` (`id`, `role`, `username`, `emailId`, `accountstatus`, `password`, `parentcompany`, `bussinessunit`, `active`) VALUES
(62, 'Admin', 'Admin', 'admin@nusconsulting.com', 'Confirmed', '$argon2i$v=19$m=65536,t=4,p=1$a085aUQyc3hKdHFSMllyQQ$bKQT8rWb/gTK6IOlavJ1BWa0mpMzrcQ9pQjfXAMBVP0', '', '', 'Active'),
(63, 'Admin', 'v', 'v@gmail.com', 'Invited', '$argon2i$v=19$m=65536,t=4,p=1$WkNvR0ROd3JOQlNKNlM1Uw$/f9JUovy2ERSfPba5lVsFJJi2/ka+cfkKr3udMesVjo', '', '', 'Inactive'),
(65, 'Parent company', 'Parent', 'parent@nusconsulting.com', 'Confirmed', '$argon2i$v=19$m=65536,t=4,p=1$ZVF2bWVHbndOd3ZBS1l0OQ$6FLYvPsDYAu+eJDQ/j8cShyTjR8TD2GcCKNWse66NFM', 'Qualesce', '', 'Active'),
(66, 'Client company', 'client', 'client@nusconsultinggroup.com', 'Confirmed', '$argon2i$v=19$m=65536,t=4,p=1$SXVCOHVoNE03RDRwOHpncw$7ue2HcaSrIiMliv3iniew2Ab6vSn5tLdEkigPBgjOmc', 'Qualesce', 'NUS Consulting Group ', 'Active'),
(68, 'Admin', 'Vijay', 'vijaygowda@gmail.com', 'Invited', '$argon2i$v=19$m=65536,t=4,p=1$T09zV2dlWFc5dzV3ZnNPSw$lN7xSsoznIKxEQAL9DtaCXoI74nqtSVeNXoThEj1ilA', '', '', 'Active'),
(69, 'Admin', 'Balaji', 'balaji.s@qualesce.com', 'Confirmed', '$argon2i$v=19$m=65536,t=4,p=1$dmZiLzM5RDBBZDYvYnNmeg$e/Sc0cDJ5vBFesyPq/aTJYduq6DIXsIbnAeDltbZg+k', '', '', 'Active'),
(70, 'Client company', 'DemoClient', 'client@qualesce.com', 'Confirmed', '$argon2i$v=19$m=65536,t=4,p=1$UTh1aTRTVTFTbEEwdHAwZw$/F3dOIkIHpJrGyMvep9MXuVKY5pgh1HmCruUaxFmGQ4', 'Ji Inc', 'Ji Solutions ', 'Active'),
(71, 'Client company', 'abc', 'abc@gmail.com', 'Confirmed', '$argon2i$v=19$m=65536,t=4,p=1$R25wY3o5NXF1aDd5QWtlbQ$+5LutOVX1w945xWiiEDAbcXEyoE91Qjc2S9eFC2aztk', 'Shell Global', 'Ji Solutions ', 'Active'),
(72, 'Parent company', 'Pp', 'pp@one.com', 'Confirmed', '$argon2i$v=19$m=65536,t=4,p=1$Q0NIVDVJV3dWZkNlZzN4dA$V98k9KP7DVM23P5HTmtRzbP+QMque6QI5+UVbq5AJNI', 'Shell Global', '', 'Active'),
(73, 'Client company', 'abd', 'abd@gmail.com', 'Confirmed', '$argon2i$v=19$m=65536,t=4,p=1$LnBZamFHRkxEQjV2ejdvMw$tsCI3EnB/5Am95cH5sAsZ8+DYU/whb4ze+4GHQmrfVs', 'Shell Global', 'Ji Solutions ', 'Active'),
(90, 'Admin', 'VIJAYK', 'vijayakumar.kt@qualesce.com', 'Invited', '$2y$10$XYwb9X9OS0HWrHASk9K3NOxeT1F6XQKlptG5NxULiEbwHCN9uIoZm', '', '', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `nus_calendermonth`
--

CREATE TABLE `nus_calendermonth` (
  `monthId` int(11) NOT NULL,
  `month` varchar(20) NOT NULL,
  `clicks` int(11) NOT NULL,
  `TradeId` int(11) NOT NULL,
  `supplierId` int(11) NOT NULL,
  `year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nus_calendermonth`
--

INSERT INTO `nus_calendermonth` (`monthId`, `month`, `clicks`, `TradeId`, `supplierId`, `year`) VALUES
(1, 'Oct', 3, 12, 9, 2022),
(2, 'Nov', 3, 12, 9, 2022),
(3, 'Dec', 3, 12, 9, 2022),
(4, 'Jan', 3, 12, 9, 2023),
(5, 'Feb', 3, 12, 9, 2023),
(6, 'Mar', 3, 12, 9, 2023),
(7, 'Apr', 3, 12, 9, 2023),
(8, 'May', 3, 12, 9, 2023),
(9, 'Jun', 3, 12, 9, 2023),
(10, 'July', 3, 12, 9, 2023),
(11, 'Aug', 3, 12, 9, 2023),
(12, 'Sep', 3, 12, 9, 2023),
(13, 'Oct', 3, 12, 9, 2023),
(14, 'Nov', 3, 12, 9, 2023),
(15, 'Dec', 3, 12, 9, 2023),
(16, 'Jan', 3, 12, 9, 2024),
(17, 'Feb', 3, 12, 9, 2024),
(18, 'Mar', 3, 12, 9, 2024),
(19, 'Apr', 3, 12, 9, 2024),
(20, 'May', 3, 12, 9, 2024),
(21, 'Jun', 3, 12, 9, 2024),
(22, 'July', 3, 12, 9, 2024),
(23, 'Aug', 3, 12, 9, 2024),
(24, 'Sep', 3, 12, 9, 2024);

-- --------------------------------------------------------

--
-- Table structure for table `nus_calenderquarter`
--

CREATE TABLE `nus_calenderquarter` (
  `querterid` int(11) NOT NULL,
  `quarters` varchar(50) NOT NULL,
  `clicks` int(11) NOT NULL,
  `tradeid` int(11) NOT NULL,
  `supplierid` int(11) NOT NULL,
  `yearoftrade` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nus_calenderquarter`
--

INSERT INTO `nus_calenderquarter` (`querterid`, `quarters`, `clicks`, `tradeid`, `supplierid`, `yearoftrade`) VALUES
(1, 'q3', 3, 2, 1, 2022),
(2, 'q4', 3, 2, 1, 2022),
(3, 'q1', 3, 2, 1, 2023),
(4, 'q2', 3, 2, 1, 2023),
(5, 'q3', 3, 2, 1, 2023),
(6, 'q4', 3, 2, 1, 2023),
(7, 'q1', 3, 2, 1, 2024),
(8, 'q2', 3, 2, 1, 2024),
(9, 'q3', 3, 2, 1, 2024),
(10, 'q3', 3, 4, 3, 2022),
(11, 'q4', 3, 4, 3, 2022),
(12, 'q1', 3, 4, 3, 2023),
(13, 'q2', 3, 4, 3, 2023),
(14, 'q3', 3, 4, 3, 2023),
(15, 'q3', 3, 6, 4, 2022),
(16, 'q4', 3, 6, 4, 2022),
(17, 'q1', 3, 6, 4, 2023),
(18, 'q2', 3, 6, 4, 2023),
(19, 'q3', 3, 6, 4, 2023),
(20, 'q4', 3, 6, 4, 2023),
(21, 'q1', 3, 6, 4, 2024),
(22, 'q2', 3, 6, 4, 2024),
(23, 'q3', 3, 6, 4, 2024),
(24, 'q4', 2, 11, 9, 2022),
(25, 'q1', 2, 11, 9, 2023),
(26, 'q2', 2, 11, 9, 2023),
(27, 'q3', 2, 11, 9, 2023),
(28, 'q4', 2, 11, 9, 2023),
(29, 'q1', 2, 11, 9, 2024),
(30, 'q2', 2, 11, 9, 2024),
(31, 'q3', 2, 11, 9, 2024);

-- --------------------------------------------------------

--
-- Table structure for table `nus_calenderyear`
--

CREATE TABLE `nus_calenderyear` (
  `calenderId` int(11) NOT NULL,
  `calenderyear` int(11) NOT NULL,
  `clicks` int(11) NOT NULL,
  `tradeId` int(11) NOT NULL,
  `supplierid` int(11) NOT NULL,
  `timeperiod` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nus_calenderyear`
--

INSERT INTO `nus_calenderyear` (`calenderId`, `calenderyear`, `clicks`, `tradeId`, `supplierid`, `timeperiod`) VALUES
(1, 2023, 3, 1, 1, '2022-9-01,2023-8-01'),
(2, 2024, 3, 1, 1, '2023-9-01,2024-8-01'),
(3, 2023, 3, 3, 3, '2022-9-01,2023-8-01'),
(4, 2023, 4, 5, 4, '2022-9-01,2023-8-01'),
(5, 2024, 4, 5, 4, '2023-9-01,2024-8-01'),
(6, 2023, 4, 7, 5, '2022-9-01,2023-8-01'),
(7, 2023, 3, 8, 7, '2022-10-01,2023-9-01'),
(8, 2024, 3, 8, 7, '2023-10-01,2024-9-01'),
(9, 2023, 2, 9, 8, '2022-10-01,2023-9-01'),
(10, 2024, 2, 9, 8, '2023-10-01,2024-9-01'),
(11, 2023, 2, 10, 9, '2022-10-01,2023-9-01'),
(12, 2024, 2, 10, 9, '2023-10-01,2024-9-01');

-- --------------------------------------------------------

--
-- Table structure for table `nus_countries`
--

CREATE TABLE `nus_countries` (
  `countryId` int(11) NOT NULL,
  `countryName` varchar(255) NOT NULL,
  `addedOn` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nus_countries`
--

INSERT INTO `nus_countries` (`countryId`, `countryName`, `addedOn`) VALUES
(1, 'India', '2022-05-19 13:20:42'),
(2, 'Sri Lanka', '2022-05-19 13:20:42'),
(3, 'United Kingdom', '2022-07-20 15:40:12');

-- --------------------------------------------------------

--
-- Table structure for table `nus_currencies`
--

CREATE TABLE `nus_currencies` (
  `id` tinyint(4) NOT NULL,
  `currencies` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nus_currencies`
--

INSERT INTO `nus_currencies` (`id`, `currencies`) VALUES
(1, 'USD'),
(2, 'EUR'),
(3, 'AUD'),
(4, 'CAD'),
(5, 'CHF'),
(6, 'CZK'),
(7, 'GBP'),
(8, 'HUF'),
(9, 'PLN'),
(10, 'SEK'),
(11, 'SGD');

-- --------------------------------------------------------

--
-- Table structure for table `nus_electricity_index`
--

CREATE TABLE `nus_electricity_index` (
  `id` tinyint(4) NOT NULL,
  `country` varchar(30) NOT NULL,
  `indexlist` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nus_electricity_index`
--

INSERT INTO `nus_electricity_index` (`id`, `country`, `indexlist`) VALUES
(1, 'Australia', 'ASX'),
(2, 'Austria', 'EEX/Austria'),
(3, 'Czech', 'EEX-PXE/Czechia'),
(4, 'Denmark', 'Nasdaq OMX/Denmark'),
(5, 'Finland', 'Nasdaq OMX/Finland'),
(6, 'France', 'EEX/France'),
(7, 'Germany', 'EEX/Deutschland'),
(8, 'Hungary', 'EEX-PXE/Hungary'),
(9, 'Hungary', 'PXE'),
(10, 'Italy', 'EEX/Italy'),
(11, 'Netherlands - Belgium\n', 'Ice Endex'),
(12, 'Norway', 'Nasdaq OMX/Norway'),
(13, 'Romania', 'OPCOM'),
(14, 'Slovakia', 'EEX-PXE/Slovakia'),
(15, 'Slovenia', 'EEX-PXE/Slovenia'),
(16, 'Spain - Portugal\n', 'OMIP'),
(17, 'Sweden ', 'Nasdaq OMX/Sweden'),
(18, 'Switzerland', 'EEX/Switzerland'),
(19, 'USA', 'CAISO NP-15 or SP-15'),
(20, 'USA', 'ERCOT North or Houston'),
(21, 'USA', 'Illinois Hub (MISO)'),
(22, 'USA', 'NEPOOL Internal Hub'),
(23, 'USA', 'NYISO Zone J (NYC area)'),
(24, 'USA', 'PJM Western Hub');

-- --------------------------------------------------------

--
-- Table structure for table `nus_naturalgas_index`
--

CREATE TABLE `nus_naturalgas_index` (
  `id` tinyint(11) NOT NULL,
  `countries` varchar(30) NOT NULL,
  `indexlist` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nus_naturalgas_index`
--

INSERT INTO `nus_naturalgas_index` (`id`, `countries`, `indexlist`) VALUES
(1, 'Austria', 'CEGH VTP'),
(2, 'Austria', 'PEGAS/CEGH VTP'),
(3, 'Czech', 'CZ VTP'),
(4, 'Denmark', 'ETF/Denmark'),
(5, 'France', 'PEG'),
(6, 'Germany - Switzerland', 'THE/PEGAS'),
(7, 'Hungary', 'CEEGEX'),
(8, 'Italy', 'PSV'),
(9, 'Netherlands', 'TTF'),
(10, 'Norway', 'ETF/Norway'),
(11, 'Romania', 'OPCOM'),
(12, 'Spain - Portugal', 'MIBGAS'),
(13, 'Sweden ', 'ETF/Sweden'),
(14, 'USA', 'NYMEX'),
(15, 'USA - Mexico', 'HSC [Houston Ship Channel]');

-- --------------------------------------------------------

--
-- Table structure for table `nus_pricing_mechanisam`
--

CREATE TABLE `nus_pricing_mechanisam` (
  `priMechId` int(11) NOT NULL,
  `pricingMechName` varchar(128) NOT NULL,
  `priceMechDesc` varchar(255) NOT NULL,
  `addedOn` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nus_pricing_mechanisam`
--

INSERT INTO `nus_pricing_mechanisam` (`priMechId`, `pricingMechName`, `priceMechDesc`, `addedOn`) VALUES
(1, 'Day Ahead', 'Spot Daily Market', '2022-05-23 13:07:28'),
(2, 'Day Ahead', 'Spot Average for month', '2022-05-23 13:08:14'),
(3, 'Month Ahead', 'Last Value', '2022-05-23 13:08:14'),
(4, 'Month Ahead', 'Average Value', '2022-05-23 13:09:07'),
(5, 'Quarter Ahead', 'Last Value', '2022-05-23 13:09:07'),
(6, 'Quarter Ahead', 'Average Value', '2022-05-23 13:09:46'),
(7, 'Calendar Ahead', 'Last Value', '2022-05-23 13:09:46');

-- --------------------------------------------------------

--
-- Table structure for table `nus_season`
--

CREATE TABLE `nus_season` (
  `seasonId` int(11) NOT NULL,
  `tradeId` int(11) NOT NULL,
  `yeartrade` int(11) NOT NULL,
  `supplierId` int(11) NOT NULL,
  `season` varchar(30) NOT NULL,
  `clicks` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nus_season`
--

INSERT INTO `nus_season` (`seasonId`, `tradeId`, `yeartrade`, `supplierId`, `season`, `clicks`) VALUES
(1, 13, 2023, 9, 'oct-mar', 3),
(2, 13, 2023, 9, 'apr-sep', 3),
(3, 13, 2024, 9, 'oct-mar', 3),
(4, 13, 2024, 9, 'apr-sep', 3);

-- --------------------------------------------------------

--
-- Table structure for table `nus_supply_contract`
--

CREATE TABLE `nus_supply_contract` (
  `supplierId` int(11) NOT NULL,
  `parentId` varchar(100) NOT NULL,
  `clientId` int(11) NOT NULL,
  `contract_id` varchar(128) NOT NULL,
  `countryName` varchar(64) NOT NULL,
  `commodityName` varchar(64) NOT NULL,
  `commodityUnits` varchar(32) NOT NULL,
  `supplyName` varchar(255) NOT NULL,
  `contractType` varchar(32) NOT NULL,
  `contractIndexId` varchar(64) NOT NULL,
  `contractTermfromDate` date NOT NULL,
  `contractTermtoDate` date NOT NULL,
  `commodityPrice` float NOT NULL,
  `totalAnualConsumption` varchar(30) NOT NULL,
  `totlconsumption` varchar(50) NOT NULL,
  `allmonts` text NOT NULL,
  `contractpricetype` varchar(30) NOT NULL,
  `indexStructureType` varchar(64) NOT NULL,
  `consumMinsize` varchar(64) NOT NULL,
  `clickTrancheminsize` int(11) NOT NULL,
  `openPrizemechanism` varchar(255) NOT NULL,
  `contractstatus` varchar(16) NOT NULL DEFAULT 'A',
  `consumptionmonth` text NOT NULL,
  `hedgeconsumption` text NOT NULL,
  `openconsumption` text NOT NULL,
  `basegenconsumption` text NOT NULL,
  `effectcon` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nus_supply_contract`
--

INSERT INTO `nus_supply_contract` (`supplierId`, `parentId`, `clientId`, `contract_id`, `countryName`, `commodityName`, `commodityUnits`, `supplyName`, `contractType`, `contractIndexId`, `contractTermfromDate`, `contractTermtoDate`, `commodityPrice`, `totalAnualConsumption`, `totlconsumption`, `allmonts`, `contractpricetype`, `indexStructureType`, `consumMinsize`, `clickTrancheminsize`, `openPrizemechanism`, `contractstatus`, `consumptionmonth`, `hedgeconsumption`, `openconsumption`, `basegenconsumption`, `effectcon`) VALUES
(1, 'Qualesce', 3, 'NUS-elec-1', 'India', 'electricity', '', 'test', 'indexed', 'ASX', '2022-09-01', '2024-08-31', 0, '12,000', '12000', '2022-9-01,2022-10-01,2022-11-01,2022-12-01,2023-1-01,2023-2-01,2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01,2024-1-01,2024-2-01,2024-3-01,2024-4-01,2024-5-01,2024-6-01,2024-7-01,2024-8-01', 'USD', 'Consumption(MWh)', '', 0, 'Month Ahead,Average Value', 'A', 'Sep-2022-1,000|Oct-2022-1,000|Nov-2022-1,000|Dec-2022-1,000|Jan-2023-1,000|Feb-2023-1,000|Mar-2023-1,000|Apr-2023-1,000|May-2023-1,000|Jun-2023-1,000|July-2023-1,000|Aug-2023-1,000|Sep-2023-1,000.00|Oct-2023-1,000.00|Nov-2023-1,000.00|Dec-2023-1,000.00|Jan-2024-1,000.00|Feb-2024-1,000.00|Mar-2024-1,000.00|Apr-2024-1,000.00|May-2024-1,000.00|Jun-2024-1,000.00|July-2024-1,000.00|Aug-2024-1,000.00', 'Sep-2022-0|Oct-2022-0|Nov-2022-0|Dec-2022-0|Jan-2023-0|Feb-2023-0|Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0', '', '', ''),
(2, 'Qualesce', 4, 'Ji-elec-2', 'Canada', 'electricity', '', 'af', 'fixed', '', '2022-09-01', '2023-08-31', 10.6, '12,000', '12000', '2022-9-01,2022-10-01,2022-11-01,2022-12-01,2023-1-01,2023-2-01,2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01', 'USD', '', '', 0, '', 'A', 'Sep-2022-1,000|Oct-2022-1,000|Nov-2022-1,000|Dec-2022-1,000|Jan-2023-1,000|Feb-2023-1,000|Mar-2023-1,000|Apr-2023-1,000|May-2023-1,000|Jun-2023-1,000|July-2023-1,000|Aug-2023-1,000', 'Sep-2022-0|Oct-2022-0|Nov-2022-0|Dec-2022-0|Jan-2023-0|Feb-2023-0|Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0', '', '', ''),
(3, 'Qualesce', 3, 'NUS-elec-3', 'India', 'electricity', '', '', 'indexed', 'ASX', '2022-09-01', '2023-08-31', 0, '12,000', '12000', '2022-9-01,2022-10-01,2022-11-01,2022-12-01,2023-1-01,2023-2-01,2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01', 'USD', 'Consumption(MWh)', '', 0, 'Quarter Ahead,Last Value', 'A', 'Sep-2022-1,000|Oct-2022-1,000|Nov-2022-1,000|Dec-2022-1,000|Jan-2023-1,000|Feb-2023-1,000|Mar-2023-1,000|Apr-2023-1,000|May-2023-1,000|Jun-2023-1,000|July-2023-1,000|Aug-2023-1,000', 'Sep-2022-0|Oct-2022-0|Nov-2022-0|Dec-2022-0|Jan-2023-0|Feb-2023-0|Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0', '', '', ''),
(4, 'Qualesce', 3, 'NUS-elec-4', 'India', 'electricity', '', 'test', 'indexed', 'ASX', '2022-09-01', '2024-08-31', 0, '12,000', '12000', '2022-9-01,2022-10-01,2022-11-01,2022-12-01,2023-1-01,2023-2-01,2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01,2024-1-01,2024-2-01,2024-3-01,2024-4-01,2024-5-01,2024-6-01,2024-7-01,2024-8-01', 'USD', 'Consumption(MWh)', '', 0, 'Day Ahead,Spot Average for month', 'A', 'Sep-2022-1,000|Oct-2022-1,000|Nov-2022-1,000|Dec-2022-1,000|Jan-2023-1,000|Feb-2023-1,000|Mar-2023-1,000|Apr-2023-1,000|May-2023-1,000|Jun-2023-1,000|July-2023-1,000|Aug-2023-1,000|Sep-2023-1,000.00|Oct-2023-1,000.00|Nov-2023-1,000.00|Dec-2023-1,000.00|Jan-2024-1,000.00|Feb-2024-1,000.00|Mar-2024-1,000.00|Apr-2024-1,000.00|May-2024-1,000.00|Jun-2024-1,000.00|July-2024-1,000.00|Aug-2024-1,000.00', 'Sep-2022-0|Oct-2022-0|Nov-2022-0|Dec-2022-0|Jan-2023-0|Feb-2023-0|Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0', '', '', ''),
(5, 'Shell Global', 6, 'Shell-elec-5', 'United Kingdom', 'electricity', '', 'tess', 'indexed', 'ASX', '2022-09-01', '2023-08-31', 0, '12,000', '12000', '2022-9-01,2022-10-01,2022-11-01,2022-12-01,2023-1-01,2023-2-01,2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01', 'USD', 'Consumption(MWh)', '', 0, 'Day Ahead,Spot Daily Market', 'A', 'Sep-2022-1,000|Oct-2022-1,000|Nov-2022-1,000|Dec-2022-1,000|Jan-2023-1,000|Feb-2023-1,000|Mar-2023-1,000|Apr-2023-1,000|May-2023-1,000|Jun-2023-1,000|July-2023-1,000|Aug-2023-1,000', 'Sep-2022-0|Oct-2022-0|Nov-2022-0|Dec-2022-0|Jan-2023-0|Feb-2023-0|Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0', '', '', ''),
(6, 'Qualesce', 3, 'NUS-elec-6', 'India', 'electricity', '', 'asd', 'fixed', '', '2022-09-01', '2023-08-31', 34.89, '12,000', '12000', '2022-9-01,2022-10-01,2022-11-01,2022-12-01,2023-1-01,2023-2-01,2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01', 'USD', '', '', 0, '', 'A', 'Sep-2022-1,000|Oct-2022-1,000|Nov-2022-1,000|Dec-2022-1,000|Jan-2023-1,000|Feb-2023-1,000|Mar-2023-1,000|Apr-2023-1,000|May-2023-1,000|Jun-2023-1,000|July-2023-1,000|Aug-2023-1,000', 'Sep-2022-0|Oct-2022-0|Nov-2022-0|Dec-2022-0|Jan-2023-0|Feb-2023-0|Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0', '', '', ''),
(7, 'Qualesce', 3, 'NUS-elec-7', 'India', 'electricity', '', 'af', 'indexed', 'ASX', '2022-10-01', '2024-09-30', 0, '12,000', '12000', '2022-10-01,2022-11-01,2022-12-01,2023-1-01,2023-2-01,2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01,2024-1-01,2024-2-01,2024-3-01,2024-4-01,2024-5-01,2024-6-01,2024-7-01,2024-8-01,2024-9-01', 'USD', 'Consumption(MWh)', '', 0, 'Day Ahead,Spot Daily Market', 'A', 'Oct-2022-1,000|Nov-2022-1,000|Dec-2022-1,000|Jan-2023-1,000|Feb-2023-1,000|Mar-2023-1,000|Apr-2023-1,000|May-2023-1,000|Jun-2023-1,000|July-2023-1,000|Aug-2023-1,000|Sep-2023-1,000|Oct-2023-1,000.00|Nov-2023-1,000.00|Dec-2023-1,000.00|Jan-2024-1,000.00|Feb-2024-1,000.00|Mar-2024-1,000.00|Apr-2024-1,000.00|May-2024-1,000.00|Jun-2024-1,000.00|July-2024-1,000.00|Aug-2024-1,000.00|Sep-2024-1,000.00', 'Oct-2022-0|Nov-2022-0|Dec-2022-0|Jan-2023-0|Feb-2023-0|Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0', '', 'Oct-2022-0|Nov-2022-0|Dec-2022-0|Jan-2023-0|Feb-2023-0|Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0', ''),
(8, 'Qualesce', 3, 'NUS-elec-8', 'India', 'electricity', '', 'test', 'indexed', 'ASX', '2022-10-01', '2024-09-30', 0, '1,200', '1200', '2022-10-01,2022-11-01,2022-12-01,2023-1-01,2023-2-01,2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01,2024-1-01,2024-2-01,2024-3-01,2024-4-01,2024-5-01,2024-6-01,2024-7-01,2024-8-01,2024-9-01', 'USD', 'Consumption(MWh)', '', 0, 'Day Ahead,Spot Daily Market', 'A', 'Oct-2022-100|Nov-2022-100|Dec-2022-100|Jan-2023-100|Feb-2023-100|Mar-2023-100|Apr-2023-100|May-2023-100|Jun-2023-100|July-2023-100|Aug-2023-100|Sep-2023-100|Oct-2023-100.00|Nov-2023-100.00|Dec-2023-100.00|Jan-2024-100.00|Feb-2024-100.00|Mar-2024-100.00|Apr-2024-100.00|May-2024-100.00|Jun-2024-100.00|July-2024-100.00|Aug-2024-100.00|Sep-2024-100.00', 'Oct-2022-0|Nov-2022-0|Dec-2022-0|Jan-2023-0|Feb-2023-0|Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0', '', 'Oct-2022-0|Nov-2022-0|Dec-2022-0|Jan-2023-0|Feb-2023-0|Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0', 'Oct-2022-0|Nov-2022-0|Dec-2022-0|Jan-2023-0|Feb-2023-0|Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0'),
(9, 'Qualesce', 3, 'NUS-elec-9', 'India', 'electricity', '', '', 'indexed', 'ASX', '2022-10-01', '2024-09-28', 0, '12,000', '12000', '2022-10-01,2022-11-01,2022-12-01,2023-1-01,2023-2-01,2023-3-01,2023-4-01,2023-5-01,2023-6-01,2023-7-01,2023-8-01,2023-9-01,2023-10-01,2023-11-01,2023-12-01,2024-1-01,2024-2-01,2024-3-01,2024-4-01,2024-5-01,2024-6-01,2024-7-01,2024-8-01,2024-9-01', 'USD', 'Consumption(MWh)', '', 0, 'Quarter Ahead,Average Value', 'A', 'Oct-2022-1,000|Nov-2022-1,000|Dec-2022-1,000|Jan-2023-1,000|Feb-2023-1,000|Mar-2023-1,000|Apr-2023-1,000|May-2023-1,000|Jun-2023-1,000|July-2023-1,000|Aug-2023-1,000|Sep-2023-1,000|Oct-2023-1,000.00|Nov-2023-1,000.00|Dec-2023-1,000.00|Jan-2024-1,000.00|Feb-2024-1,000.00|Mar-2024-1,000.00|Apr-2024-1,000.00|May-2024-1,000.00|Jun-2024-1,000.00|July-2024-1,000.00|Aug-2024-1,000.00|Sep-2024-1,000.00', 'Oct-2022-0|Nov-2022-0|Dec-2022-0|Jan-2023-0|Feb-2023-0|Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0', '', 'Oct-2022-0|Nov-2022-0|Dec-2022-0|Jan-2023-0|Feb-2023-0|Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0', 'Oct-2022-0|Nov-2022-0|Dec-2022-0|Jan-2023-0|Feb-2023-0|Mar-2023-0|Apr-2023-0|May-2023-0|Jun-2023-0|July-2023-0|Aug-2023-0|Sep-2023-0|Oct-2023-0|Nov-2023-0|Dec-2023-0|Jan-2024-0|Feb-2024-0|Mar-2024-0|Apr-2024-0|May-2024-0|Jun-2024-0|July-2024-0|Aug-2024-0|Sep-2024-0');

-- --------------------------------------------------------

--
-- Table structure for table `nus_tradeperiods`
--

CREATE TABLE `nus_tradeperiods` (
  `tradePerId` int(11) NOT NULL,
  `supplierId` int(11) NOT NULL,
  `periodsId` varchar(128) NOT NULL,
  `clicktracnches` int(11) NOT NULL,
  `clicktranches` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nus_tradeperiods`
--

INSERT INTO `nus_tradeperiods` (`tradePerId`, `supplierId`, `periodsId`, `clicktracnches`, `clicktranches`) VALUES
(1, 1, 'Calendar Yearly', 3, '% consumption'),
(2, 1, 'Calendar Quarterly', 3, '#MWhs'),
(3, 3, 'Calendar Yearly', 3, '% consumption'),
(4, 3, 'Calendar Quarterly', 3, '#MWhs'),
(5, 4, 'Calendar Yearly', 4, '% consumption'),
(6, 4, 'Calendar Quarterly', 3, '#MWhs'),
(7, 5, 'Calendar Yearly', 4, '% consumption'),
(8, 7, 'Calendar Yearly', 3, '% consumption'),
(9, 8, 'Calendar Yearly', 2, '#MWhs'),
(10, 9, 'Calendar Yearly', 2, '% consumption'),
(11, 9, 'Calendar Quarterly', 2, '% consumption'),
(12, 9, 'Calendar Monthly', 3, '% consumption'),
(13, 9, 'Season', 3, '#MWhs');

-- --------------------------------------------------------

--
-- Table structure for table `nus_trade_periods_list`
--

CREATE TABLE `nus_trade_periods_list` (
  `tPeriodsId` int(11) NOT NULL,
  `periodsName` varchar(128) NOT NULL,
  `addedOn` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `parentcompanydata`
--

CREATE TABLE `parentcompanydata` (
  `id` int(11) NOT NULL,
  `parentcompany` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `parentcompanydata`
--

INSERT INTO `parentcompanydata` (`id`, `parentcompany`) VALUES
(3, 'Qualesce'),
(4, 'Ji Inc'),
(5, 'Shell Global');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clientcompanydata`
--
ALTER TABLE `clientcompanydata`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `clientcompany` (`clientcompany`);

--
-- Indexes for table `enter_trade`
--
ALTER TABLE `enter_trade`
  ADD PRIMARY KEY (`tradeId`);

--
-- Indexes for table `nususerdata`
--
ALTER TABLE `nususerdata`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`,`emailId`),
  ADD UNIQUE KEY `username_2` (`username`,`emailId`),
  ADD UNIQUE KEY `username_3` (`username`),
  ADD UNIQUE KEY `emailId` (`emailId`);

--
-- Indexes for table `nus_calendermonth`
--
ALTER TABLE `nus_calendermonth`
  ADD PRIMARY KEY (`monthId`);

--
-- Indexes for table `nus_calenderquarter`
--
ALTER TABLE `nus_calenderquarter`
  ADD PRIMARY KEY (`querterid`);

--
-- Indexes for table `nus_calenderyear`
--
ALTER TABLE `nus_calenderyear`
  ADD PRIMARY KEY (`calenderId`);

--
-- Indexes for table `nus_countries`
--
ALTER TABLE `nus_countries`
  ADD PRIMARY KEY (`countryId`);

--
-- Indexes for table `nus_currencies`
--
ALTER TABLE `nus_currencies`
  ADD PRIMARY KEY (`id`,`currencies`),
  ADD UNIQUE KEY `currencies` (`currencies`),
  ADD UNIQUE KEY `currencies_2` (`currencies`);

--
-- Indexes for table `nus_electricity_index`
--
ALTER TABLE `nus_electricity_index`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nus_naturalgas_index`
--
ALTER TABLE `nus_naturalgas_index`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `nus_pricing_mechanisam`
--
ALTER TABLE `nus_pricing_mechanisam`
  ADD PRIMARY KEY (`priMechId`);

--
-- Indexes for table `nus_season`
--
ALTER TABLE `nus_season`
  ADD PRIMARY KEY (`seasonId`);

--
-- Indexes for table `nus_supply_contract`
--
ALTER TABLE `nus_supply_contract`
  ADD PRIMARY KEY (`supplierId`);

--
-- Indexes for table `nus_tradeperiods`
--
ALTER TABLE `nus_tradeperiods`
  ADD PRIMARY KEY (`tradePerId`);

--
-- Indexes for table `nus_trade_periods_list`
--
ALTER TABLE `nus_trade_periods_list`
  ADD PRIMARY KEY (`tPeriodsId`);

--
-- Indexes for table `parentcompanydata`
--
ALTER TABLE `parentcompanydata`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clientcompanydata`
--
ALTER TABLE `clientcompanydata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `enter_trade`
--
ALTER TABLE `enter_trade`
  MODIFY `tradeId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `nususerdata`
--
ALTER TABLE `nususerdata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `nus_calendermonth`
--
ALTER TABLE `nus_calendermonth`
  MODIFY `monthId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `nus_calenderquarter`
--
ALTER TABLE `nus_calenderquarter`
  MODIFY `querterid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `nus_calenderyear`
--
ALTER TABLE `nus_calenderyear`
  MODIFY `calenderId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `nus_countries`
--
ALTER TABLE `nus_countries`
  MODIFY `countryId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `nus_currencies`
--
ALTER TABLE `nus_currencies`
  MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `nus_electricity_index`
--
ALTER TABLE `nus_electricity_index`
  MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `nus_naturalgas_index`
--
ALTER TABLE `nus_naturalgas_index`
  MODIFY `id` tinyint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `nus_pricing_mechanisam`
--
ALTER TABLE `nus_pricing_mechanisam`
  MODIFY `priMechId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `nus_season`
--
ALTER TABLE `nus_season`
  MODIFY `seasonId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `nus_supply_contract`
--
ALTER TABLE `nus_supply_contract`
  MODIFY `supplierId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `nus_tradeperiods`
--
ALTER TABLE `nus_tradeperiods`
  MODIFY `tradePerId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `nus_trade_periods_list`
--
ALTER TABLE `nus_trade_periods_list`
  MODIFY `tPeriodsId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `parentcompanydata`
--
ALTER TABLE `parentcompanydata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
